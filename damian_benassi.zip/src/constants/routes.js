export const HOME = '/';
export const RENAME = '/rename/:page/:file/';
export const RENAME_TAG = '/rename/:page/:file/:tag';
export const PAGE = '/filter/:page';
export const FILTER = '/filter/:page/:tag';
